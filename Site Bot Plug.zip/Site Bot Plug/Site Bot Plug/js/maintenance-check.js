// Script para verificar o modo de manutenção em todas as páginas
(function() {
  // Lista de páginas que não precisam ser redirecionadas mesmo em modo de manutenção
  const exemptPages = [
    '/login', 
    '/registro', 
    '/manutencao.html',
    '/painel-ad7x9z3m2k1',
    '/admin.html'
  ];
  
  /**
   * Verifica se o usuário atual é um administrador/desenvolvedor
   * @returns {boolean} True se for admin, false caso contrário
   */
  function isAdmin() {
    if (typeof isDevUser === 'function') {
      return isDevUser();
    }
    
    // Implementação de backup
    try {
      const userData = localStorage.getItem('botplug_user');
      if (!userData) return false;
      
      const user = JSON.parse(userData);
      return user.role === 'developer' || user.isDev === true;
    } catch (err) {
      console.error('Erro ao verificar status de admin:', err);
      return false;
    }
  }
  
  /**
   * Verifica se o usuário está autenticado
   * @returns {boolean} True se estiver logado, false caso contrário
   */
  function isAuthenticated() {
    if (typeof window.isAuthenticated === 'function') {
      return window.isAuthenticated();
    }
    
    // Implementação de backup
    try {
      const token = localStorage.getItem('botplug_token');
      const userData = localStorage.getItem('botplug_user');
      return token !== null && userData !== null;
    } catch (err) {
      console.error('Erro ao verificar autenticação:', err);
      return false;
    }
  }
  
  /**
   * Verifica se a página atual está na lista de exceções
   * @returns {boolean} True se a página atual estiver na lista de exceções
   */
  function isExemptPage() {
    const currentPath = window.location.pathname;
    
    return exemptPages.some(page => {
      // Verificar correspondência direta
      if (currentPath === page) return true;
      // Verificar se é uma página HTML
      if (page.endsWith('.html') && currentPath === page.replace('.html', '')) return true;
      // Verificar se o caminho atual termina com a página isenta
      return currentPath.endsWith(page);
    });
  }
  
  /**
   * Verifica o status do modo de manutenção a partir da API
   * @returns {Promise<boolean>} Promise que resolve para true se o modo de manutenção estiver ativo
   */
  async function fetchMaintenanceStatus() {
    try {
      // Verificar configuração de manutenção no servidor
      // Adicionar timestamp para evitar cache
      const timestamp = new Date().getTime();
      const response = await fetch(`/api/maintenance?t=${timestamp}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        }
      });
      
      // Se a API retornar erro, tentar o fallback
      if (!response.ok) {
        return fetchMaintenanceFallback();
      }
      
      const settings = await response.json();
      return settings.enabled === true;
    } catch (err) {
      console.error('Erro ao verificar modo de manutenção na API:', err);
      // Se houver erro na API, tentar o fallback
      return fetchMaintenanceFallback();
    }
  }
  
  /**
   * Método de fallback para verificar status de manutenção através de arquivo JSON
   * @returns {Promise<boolean>} Promise que resolve para true se o modo de manutenção estiver ativo
   */
  async function fetchMaintenanceFallback() {
    try {
      // Tentar acessar diretamente o endpoint de status
      const timestamp = new Date().getTime();
      const response = await fetch(`/api/maintenance-status?t=${timestamp}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        }
      });
      
      if (!response.ok) {
        console.error('Falha ao verificar status de manutenção');
        // Tentar a alternativa de localStorage como último recurso
        return checkLocalStorageMaintenance();
      }
      
      const settings = await response.json();
      return settings.enabled === true;
    } catch (err) {
      console.error('Erro ao verificar modo de manutenção via API alternativa:', err);
      // Se tudo falhar, usar localStorage
      return checkLocalStorageMaintenance();
    }
  }
  
  /**
   * Verifica o status de manutenção no localStorage como último recurso
   * @returns {boolean} True se o modo de manutenção estiver ativo no localStorage
   */
  function checkLocalStorageMaintenance() {
    try {
      const maintenanceSettings = localStorage.getItem('botplug_maintenance_settings');
      if (maintenanceSettings) {
        const settings = JSON.parse(maintenanceSettings);
        return settings.enabled === true;
      }
      
      // Verificar nas configurações gerais
      const adminSettings = localStorage.getItem('botplug_admin_settings');
      if (adminSettings) {
        const settings = JSON.parse(adminSettings);
        return settings.maintenanceMode === true;
      }
    } catch (e) {
      console.error('Erro ao verificar localStorage:', e);
    }
    
    return false;
  }
  
  /**
   * Função principal que faz a verificação e redirecionamento
   */
  async function checkMaintenance() {
    // Verificar se a própria página é de manutenção e não fazer nada
    if (window.location.pathname.includes('manutencao.html')) {
      return;
    }
    
    try {
      // Verificar modo de manutenção
      const maintenanceActive = await fetchMaintenanceStatus();
      
      // Se não estiver em manutenção, não fazer nada
      if (!maintenanceActive) {
        return;
      }
      
      // Se for admin, não redirecionar, apenas mostrar notificação
      if (isAdmin()) {
        if (!isExemptPage()) {
          showMaintenanceNotice();
        }
        return;
      }
      
      // Se estiver nas páginas de login ou registro, permitir acesso
      if (['/login', '/registro', '/login.html', '/registro.html'].some(page => 
          window.location.pathname.includes(page))) {
        return;
      }
      
      // Se a página atual estiver na lista de exceções, não redirecionar
      if (isExemptPage()) {
        return;
      }
      
      // Redirecionar para a página de manutenção
      window.location.href = '/manutencao.html';
    } catch (error) {
      console.error('Erro crítico na verificação de manutenção:', error);
    }
  }
  
  /**
   * Mostra uma notificação para administradores quando o site está em manutenção
   */
  function showMaintenanceNotice() {
    // Verificar se já existe uma notificação
    if (document.getElementById('maintenance-admin-notice')) {
      return;
    }
    
    // Criar elemento de notificação
    const notice = document.createElement('div');
    notice.id = 'maintenance-admin-notice';
    notice.style.position = 'fixed';
    notice.style.bottom = '20px';
    notice.style.right = '20px';
    notice.style.backgroundColor = '#ff3d3d';
    notice.style.color = '#fff';
    notice.style.padding = '10px 15px';
    notice.style.borderRadius = '4px';
    notice.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
    notice.style.zIndex = '9999';
    notice.style.fontSize = '14px';
    notice.innerHTML = '<strong>Modo de Manutenção Ativo</strong> - Outros usuários não podem acessar o site.';
    
    // Adicionar botão de fechar
    const closeBtn = document.createElement('button');
    closeBtn.style.backgroundColor = 'transparent';
    closeBtn.style.border = 'none';
    closeBtn.style.color = '#fff';
    closeBtn.style.marginLeft = '10px';
    closeBtn.style.cursor = 'pointer';
    closeBtn.innerHTML = '✕';
    closeBtn.onclick = function() {
      document.body.removeChild(notice);
    };
    
    notice.appendChild(closeBtn);
    document.body.appendChild(notice);
  }
  
  // Executar verificação quando o DOM estiver carregado
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', checkMaintenance);
  } else {
    checkMaintenance();
  }
})(); 