// Sistema de autenticação simplificado usando localStorage
// Ideal para prototipagem e demonstração

// Constantes
const STORAGE_KEY_USER = "botplug_user";
const STORAGE_KEY_TOKEN = "botplug_token";
const STORAGE_KEY_LIBRARY_BOTS = "biblioteca_bots";
const STORAGE_KEY_ADMIN_BOTS = "admin_bots";
// URL da API que simula armazenamento compartilhado (pode ser substituída por uma API real posteriormente)
const SHARED_STORAGE_API = "https://api.botplug.com/shared-storage";

// Verifica se o usuário está autenticado
function isAuthenticated() {
  const token = localStorage.getItem(STORAGE_KEY_TOKEN);
  const user = localStorage.getItem(STORAGE_KEY_USER);
  // Verificação mais robusta: token E user devem existir
  return token !== null && user !== null;
}

// Obter dados do usuário atual
function getCurrentUser() {
  const userData = localStorage.getItem(STORAGE_KEY_USER);
  return userData ? JSON.parse(userData) : null;
}

// Verifica se o usuário atual é um desenvolvedor
function isDevUser() {
  const user = getCurrentUser();
  if (!user) return false;
  
  // Verificar se o usuário tem email ou username de desenvolvedor
  return user.email === "lucasalto50@gmail.com" || 
         user.username === "rogerinho" || 
         user.role === "developer";
}

// Limpar dados de autenticação (útil para resolver problemas)
function clearAuthData() {
  localStorage.removeItem(STORAGE_KEY_TOKEN);
  localStorage.removeItem(STORAGE_KEY_USER);
  localStorage.removeItem('botplug_users');
  
  // Atualizar interface após limpar
  updateAuthUI();
  
  alert("Dados de autenticação limpos com sucesso. Você pode tentar se registrar novamente.");
}

// Efetuar login
function login(email, password) {
  // Em um sistema real, isso seria uma chamada de API
  // Para fins de demonstração, vamos simular um login
  
  // Verificar se existe algum usuário registrado
  const users = getAllUsers();
  const user = users.find(u => u.email === email);
  
  if (!user) {
    return { success: false, message: "Usuário não encontrado" };
  }
  
  if (user.password !== password) {
    return { success: false, message: "Senha incorreta" };
  }
  
  // Gerar um token simulado
  const token = generateToken();
  
  // Salvar dados no localStorage
  localStorage.setItem(STORAGE_KEY_TOKEN, token);
  
  // Remover senha antes de armazenar os dados do usuário
  const { password: pwd, ...userWithoutPassword } = user;
  localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(userWithoutPassword));
  
  // Atualizar interface
  updateAuthUI();
  
  // Sincronizar bots compartilhados ao fazer login
  syncSharedBots();
  
  return { success: true, message: "Login realizado com sucesso" };
}

// Registro de novo usuário
function register(userData) {
  try {
    // Verificar se já existe um usuário com este email
    const users = getAllUsers();
    if (users.some(u => u.email === userData.email)) {
      return { success: false, message: "Este email já está em uso" };
    }
    
    if (users.some(u => u.username === userData.username)) {
      return { success: false, message: "Este nome de usuário já está em uso" };
    }
    
    // Adicionar data de criação
    userData.createdAt = new Date().toISOString();
    
    // Salvar o novo usuário
    users.push(userData);
    localStorage.setItem('botplug_users', JSON.stringify(users));
    
    // Fazer login automático após o registro
    return login(userData.email, userData.password);
  } catch (error) {
    console.error("Erro no registro:", error);
    return { success: false, message: "Ocorreu um erro durante o registro. Tente novamente." };
  }
}

// Logout
function logout() {
  try {
    // Remover dados de autenticação
    localStorage.removeItem(STORAGE_KEY_TOKEN);
    localStorage.removeItem(STORAGE_KEY_USER);
    
    // Atualizar interface
    updateAuthUI();
    
    // Redirecionar para a página inicial
    window.location.href = "/menu";
  } catch (error) {
    console.error("Erro ao fazer logout:", error);
  }
}

// Funções auxiliares
function getAllUsers() {
  try {
    const usersData = localStorage.getItem('botplug_users');
    return usersData ? JSON.parse(usersData) : [];
  } catch (error) {
    console.error("Erro ao obter usuários:", error);
    // Se houver erro, retorna array vazio
    return [];
  }
}

function generateToken() {
  // Na prática, seria um JWT ou outra forma segura de token
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

// Atualizar interface com base no estado de autenticação
function updateAuthUI() {
  try {
    // Verificar se os elementos existem na página atual
    const loginLinks = document.querySelectorAll('.login-link');
    const userNav = document.getElementById('user-nav');
    const authMenu = document.getElementById('auth-menu');
    const devElements = document.querySelectorAll('.dev-only');
    
    if ((!loginLinks.length && !userNav) && !authMenu) {
      // A página atual não tem elementos de autenticação
      return;
    }
    
    if (isAuthenticated()) {
      // Usuário está autenticado
      
      // Verificar se é um usuário desenvolvedor
      const isDev = isDevUser();
      
      // Mostrar/ocultar elementos exclusivos para desenvolvedores
      if (devElements.length > 0) {
        devElements.forEach(el => {
          el.style.display = isDev ? 'block' : 'none';
        });
      }
      
      // Esconder o menu de autenticação quando logado
      if (authMenu) {
        authMenu.style.display = 'none';
      }
      
      // Esconder links de login/registro tradicionais
      loginLinks.forEach(link => {
        link.style.display = 'none';
      });
      
      if (userNav) {
        // Atualizar informações do usuário
        const user = getCurrentUser();
        const userNameElement = userNav.querySelector('.user-name');
        if (userNameElement) {
          // Adicionar uma indicação visual se for DEV
          if (isDev) {
            userNameElement.textContent = user.username + " ⚡";
            userNameElement.style.color = "#ffcc00";
          } else {
            userNameElement.textContent = user.username;
            userNameElement.style.color = "";
          }
        }
        
        // Mostrar menu do usuário com display block ao invés de flex
        userNav.style.display = 'block';
        
        // Adicionar classe especial se for DEV
        if (isDev) {
          userNav.classList.add('dev-user');
        } else {
          userNav.classList.remove('dev-user');
        }
        
        // Configurar evento de logout
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
          logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
          });
        }
      }
    } else {
      // Usuário não está autenticado
      
      // Ocultar elementos exclusivos para desenvolvedores
      if (devElements.length > 0) {
        devElements.forEach(el => {
          el.style.display = 'none';
        });
      }
      
      // Mostrar o menu de autenticação quando não logado
      if (authMenu) {
        authMenu.style.display = 'block';
      }
      
      // Configurar exibição dos links tradicionais se o novo menu não existir
      if (!authMenu) {
        loginLinks.forEach(link => {
          link.style.display = 'flex';
        });
      } else {
        // Esconder links tradicionais se o novo menu existir
        loginLinks.forEach(link => {
          link.style.display = 'none';
        });
      }
      
      if (userNav) {
        userNav.style.display = 'none';
        userNav.classList.remove('dev-user');
      }
    }
  } catch (error) {
    console.error('Erro ao atualizar interface de autenticação:', error);
  }
}

// Executar quando o documento estiver carregado
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAuth);
} else {
  initAuth();
}

// Inicializar sistema de autenticação
function initAuth() {
  // Verificar se a página atual precisa de autenticação
  const requiresAuth = document.body.hasAttribute('data-requires-auth');
  if (requiresAuth && !isAuthenticated()) {
    window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname);
    return;
  }
  
  // Configurar usuário desenvolvedor se não existir
  setupDevAccount();
  
  // Atualizar a interface baseada no estado de autenticação
  updateAuthUI();
  
  // Verificar se há formulário de login na página
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLoginForm);
  }
  
  // Verificar se há formulário de registro na página
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', handleRegisterForm);
  }
  
  // Verificar se há botão de limpar dados
  const clearDataBtn = document.getElementById('clear-auth-data');
  if (clearDataBtn) {
    clearDataBtn.addEventListener('click', function() {
      clearAuthData();
      localStorage.removeItem('botplug_users');
      localStorage.removeItem('botplug_saved_bots');
      alert('Dados de autenticação limpos com sucesso. Tente criar uma nova conta.');
      window.location.href = '/login';
    });
  }
  
  // Verificar se estamos na página da biblioteca
  if (window.location.pathname.includes('biblioteca')) {
    initLibraryPage();
  }
  
  // Verificar se precisa carregar bots na biblioteca
  loadLibraryBots();
  
  // Carregar bots compartilhados ao iniciar
  syncSharedBots();
}

// Inicializar a página da biblioteca
function initLibraryPage() {
  // Verificar se existem bots na biblioteca
  const libraryBots = localStorage.getItem(STORAGE_KEY_LIBRARY_BOTS);
  
  // Se não existirem bots na biblioteca, mas existirem no painel admin, copiar para a biblioteca
  if (!libraryBots) {
    const adminBots = localStorage.getItem(STORAGE_KEY_ADMIN_BOTS);
    if (adminBots) {
      const adminBotsList = JSON.parse(adminBots);
      
      // Converter bots do admin para o formato da biblioteca
      const libraryBotsList = adminBotsList.map(bot => ({
        id: bot.id,
        name: bot.name,
        image: bot.image,
        category: bot.category,
        description: bot.description,
        type: bot.type,
        price: bot.price,
        downloadLink: bot.downloadLink,
        downloads: bot.downloads || 0,
        rating: 5, // Valor padrão para novos bots
        tags: bot.tags,
        featured: bot.status === 'featured',
        dateAdded: bot.date,
        contributor: bot.contributor
      }));
      
      // Salvar no localStorage da biblioteca
      localStorage.setItem(STORAGE_KEY_LIBRARY_BOTS, JSON.stringify(libraryBotsList));
      
      // Compartilhar esses bots no armazenamento compartilhado
      shareBotsWithAllUsers(libraryBotsList);
      
      console.log('Bots do painel administrativo copiados para a biblioteca:', libraryBotsList.length);
    }
  }
}

// Configurar conta de desenvolvedor
function setupDevAccount() {
  const users = getAllUsers();
  const devExists = users.some(u => u.email === "dev@botplug.com" || u.username === "dev");
  
  if (!devExists) {
    // Criar conta de desenvolvedor
    const devUser = {
      username: "dev",
      email: "dev@botplug.com",
      password: "botplug123",
      role: "developer",
      firstName: "Developer",
      lastName: "Account",
      createdAt: new Date().toISOString()
    };
    
    // Adicionar à lista de usuários
    users.push(devUser);
    localStorage.setItem('botplug_users', JSON.stringify(users));
    console.log("Conta de desenvolvedor criada com sucesso!");
  }
}

// Manipular envio do formulário de login
function handleLoginForm(e) {
  e.preventDefault();
  
  // Verificar se estamos na página de login
  // Somente redirecionar se o usuário estiver autenticado E a página for carregada diretamente
  if (isAuthenticated() && !window.location.search.includes('error')) {
    window.location.href = "/biblioteca";
    return;
  }
  
  // Obter dados do formulário
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const remember = document.getElementById('remember') ? document.getElementById('remember').checked : false;
  
  // Tentar fazer login
  const result = login(email, password, remember);
  
  if (result.success) {
    window.location.href = "/biblioteca";
  } else {
    alert(result.message);
  }
}

// Manipular envio do formulário de registro
function handleRegisterForm(e) {
  e.preventDefault();
  
  // Verificar se estamos na página de registro
  // Somente redirecionar se o usuário estiver autenticado E a página for carregada diretamente
  if (isAuthenticated() && !window.location.search.includes('error')) {
    window.location.href = "/biblioteca";
    return;
  }
  
  // Validar senha
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirm-password').value;
  
  if (password !== confirmPassword) {
    alert("As senhas não coincidem");
    return;
  }
  
  // Coletar dados do formulário
  const userData = {
    firstName: document.getElementById('first-name').value,
    lastName: document.getElementById('last-name').value,
    username: document.getElementById('username').value,
    email: document.getElementById('email').value,
    password: password,
    discordId: document.getElementById('discord-id') ? document.getElementById('discord-id').value : "",
    experience: document.getElementById('experience') ? document.getElementById('experience').value : "beginner"
  };
  
  const result = register(userData);
  
  if (result.success) {
    window.location.href = "/biblioteca";
  } else {
    // Se o registro falhar, adiciona um parâmetro na URL para evitar redirecionamento automático
    window.history.replaceState(null, "", window.location.pathname + "?error=true");
    alert(result.message);
  }
}

// Função para carregar bots do admin para biblioteca
function syncAdminBotsToLibrary() {
  const adminBots = localStorage.getItem(STORAGE_KEY_ADMIN_BOTS);
  if (adminBots) {
    // Salvar bots do admin na biblioteca
    localStorage.setItem(STORAGE_KEY_LIBRARY_BOTS, adminBots);
    // Também compartilhar esses bots com todos os usuários
    shareBotsWithAllUsers(JSON.parse(adminBots));
    console.log('Bots do painel de administração sincronizados com a biblioteca');
  }
}

// Função para verificar e carregar bots na biblioteca
function loadLibraryBots() {
  // Verificar se estamos na página da biblioteca
  if (window.location.pathname.includes('biblioteca.html')) {
    console.log('Carregando bots para a biblioteca');
    syncAdminBotsToLibrary();
    // Também carrega bots compartilhados
    syncSharedBots();
  }
}

// Função para compartilhar bots com todos os usuários
function shareBotsWithAllUsers(bots) {
  try {
    console.log('Compartilhando bots com todos os usuários...');
    
    // Usar os bots recebidos diretamente para todos os armazenamentos
    const botsJson = JSON.stringify(bots);
    
    // Primeiro, limpar todos os locais para evitar conflitos
    localStorage.removeItem('admin_bots');
    localStorage.removeItem('biblioteca_bots');
    localStorage.removeItem('shared_biblioteca_bots');
    localStorage.removeItem('botplug_saved_bots');
    
    // Aguardar um momento para garantir que a limpeza foi concluída
    setTimeout(() => {
      // Salvar em todos os locais de armazenamento
      localStorage.setItem('admin_bots', botsJson);
      localStorage.setItem('biblioteca_bots', botsJson);
      localStorage.setItem('shared_biblioteca_bots', botsJson);
      
      // Salvar também em botplug_saved_bots que é usado para bots salvos do usuário
      localStorage.setItem('botplug_saved_bots', botsJson);
      
      // Atualizar a versão global de sincronização
      localStorage.setItem('global_bots_version', 'botplug_' + new Date().getTime());
      
      console.log('Bots compartilhados com sucesso em todos os armazenamentos:', bots.length);
      
      // Forçar atualização da exibição se estiver na página de biblioteca
      if (window.location.pathname.includes('biblioteca')) {
        console.log('Detectada página de biblioteca - forçando atualização da visualização');
        
        // Verificar se há função de atualização disponível
        if (typeof sincronizarECarregarBots === 'function') {
          setTimeout(() => {
            sincronizarECarregarBots();
          }, 100);
        } else if (typeof displayBots === 'function' && typeof loadBotsFromLocalStorage === 'function') {
          // Alternativa: usar funções separadas
          setTimeout(() => {
            const loadedBots = loadBotsFromLocalStorage();
            if (loadedBots && loadedBots.length > 0) {
              displayBots(loadedBots, 1);
            }
          }, 100);
        }
      }
    }, 100);
    
    return true;
  } catch (error) {
    console.error('Erro ao compartilhar bots:', error);
    return false;
  }
}

// Função para sincronizar bots compartilhados
function syncSharedBots() {
  try {
    console.log('Iniciando sincronização de bots compartilhados...');
    
    // Verificar se existem bots na lista admin_bots (esta é a fonte principal)
    const adminBotsData = localStorage.getItem('admin_bots');
    if (adminBotsData) {
      // Obter bots do admin
      const adminBots = JSON.parse(adminBotsData);
      console.log('Bots encontrados no admin:', adminBots.length);
      
      // Primeiro, limpar outros armazenamentos para evitar conflitos
      localStorage.removeItem('shared_biblioteca_bots');
      localStorage.removeItem('biblioteca_bots');
      
      // Aguardar um momento para garantir que a limpeza foi concluída
      setTimeout(() => {
        // Salvar na área compartilhada
        localStorage.setItem('shared_biblioteca_bots', adminBotsData);
        
        // Também salvar na biblioteca local do usuário
        localStorage.setItem('biblioteca_bots', adminBotsData);
        
        // Atualizar a versão global de sincronização
        localStorage.setItem('global_bots_version', 'botplug_' + new Date().getTime());
        
        console.log('Bots do admin sincronizados com o armazenamento compartilhado e local');
        
        // Forçar atualização da interface se estiver na página da biblioteca
        if (window.location.pathname.includes('biblioteca')) {
          if (typeof sincronizarECarregarBots === 'function') {
            setTimeout(() => {
              sincronizarECarregarBots();
            }, 100);
          }
        }
      }, 100);
      
      return true;
    }
    
    // Se não existirem bots no admin, verificar se existem na área compartilhada
    const sharedBotsData = localStorage.getItem('shared_biblioteca_bots');
    if (sharedBotsData) {
      const sharedBots = JSON.parse(sharedBotsData);
      console.log('Bots encontrados no armazenamento compartilhado:', sharedBots.length);
      
      // Limpar outros locais antes de salvar
      localStorage.removeItem('biblioteca_bots');
      localStorage.removeItem('admin_bots');
      
      setTimeout(() => {
        // Salvar na biblioteca local do usuário e no admin
        localStorage.setItem('biblioteca_bots', sharedBotsData);
        localStorage.setItem('admin_bots', sharedBotsData);
        
        // Atualizar a versão global de sincronização
        localStorage.setItem('global_bots_version', 'botplug_' + new Date().getTime());
        
        console.log('Bots compartilhados sincronizados com a biblioteca local');
        
        // Forçar atualização da interface se estiver na página da biblioteca
        if (window.location.pathname.includes('biblioteca')) {
          if (typeof sincronizarECarregarBots === 'function') {
            setTimeout(() => {
              sincronizarECarregarBots();
            }, 100);
          }
        }
      }, 100);
      
      return true;
    }
    
    console.log('Nenhum bot encontrado para sincronização');
    return false;
  } catch (error) {
    console.error('Erro ao sincronizar bots compartilhados:', error);
    return false;
  }
} 