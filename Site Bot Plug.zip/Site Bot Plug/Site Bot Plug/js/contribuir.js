// Configuração do webhook do Discord
const DISCORD_WEBHOOK_URL = "https://discordapp.com/api/webhooks/1374179068164964383/3fWCkYpQyLnzvgOeimV5SBNKwMOk7PDeUuzli0ymWIaos4A4-HzySPy1CF90PByMu7Q9"; // Substitua pelo URL do seu webhook

// Função para formatar dados para o Discord
function formatarDadosParaDiscord(dados) {
  // Cores para o embed
  const BLUE_COLOR = 4886754; // Cor azul da sua UI (#4285f4)
  
  // Formatar as tecnologias selecionadas
  const tecnologias = dados.technologies.join(", ");
  
  // Criar o embed para o Discord
  const embed = {
    title: "🤖 Nova Contribuição de Bot",
    color: BLUE_COLOR,
    thumbnail: {
      url: dados.imageLink // Thumbnail pequena
    },
    image: {
      url: dados.imageLink // Imagem grande e completa
    },
    fields: [
      {
        name: "📝 Nome do Bot",
        value: dados.botName,
        inline: true
      },
      {
        name: "🏷️ Categoria",
        value: dados.botType,
        inline: true
      },
      {
        name: "👤 Discord",
        value: dados.discordUsername,
        inline: true
      },
      {
        name: "📋 Descrição",
        value: dados.botDescription
      },
      {
        name: "🔗 Link para Download",
        value: dados.downloadLink
      },
      {
        name: "🔧 Tecnologias",
        value: tecnologias || "Nenhuma tecnologia especificada"
      }
    ],
    timestamp: new Date().toISOString(),
    footer: {
      text: "BotPlug - Sistema de Contribuição"
    }
  };

  // Retornar a estrutura completa do webhook
  return {
    username: "BotPlug Notificações",
    avatar_url: "https://i.imgur.com/seu_logo.png", // Substitua pelo URL do seu logo
    content: `📢 **Nova contribuição de bot recebida!** Imagem do bot: ${dados.imageLink}`,
    embeds: [embed]
  };
}

// Função para enviar dados para o webhook do Discord
async function enviarParaDiscord(dados) {
  try {
    const webhookData = formatarDadosParaDiscord(dados);
    
    const response = await fetch(DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(webhookData)
    });
    
    if (!response.ok) {
      throw new Error(`Erro ao enviar para Discord: ${response.status}`);
    }
    
    return true;
  } catch (error) {
    console.error("Erro ao enviar para webhook do Discord:", error);
    return false;
  }
}

// Função para coletar dados do formulário
function coletarDadosFormulario() {
  // Pegar todos os valores do formulário
  const botName = document.getElementById("bot-name").value;
  const botType = document.getElementById("bot-type").value;
  const discordUsername = document.getElementById("discord-username").value;
  const botDescription = document.getElementById("bot-description").value;
  const downloadLink = document.getElementById("download-link").value;
  const imageLink = document.getElementById("image-link").value;
  
  // Coletar tecnologias marcadas
  const techCheckboxes = document.querySelectorAll('input[name="technologies"]:checked');
  const technologies = Array.from(techCheckboxes).map(checkbox => checkbox.value);
  
  return {
    botName,
    botType,
    discordUsername,
    botDescription,
    downloadLink,
    imageLink,
    technologies
  };
}

// Validar o formulário e retornar se é válido
function validarFormulario() {
  let isValid = true;
  const requiredFields = ["bot-name", "bot-type", "discord-username", "bot-description", "download-link", "image-link"];
  
  // Verificar campos obrigatórios
  requiredFields.forEach(fieldId => {
    const field = document.getElementById(fieldId);
    if (!field.value.trim()) {
      mostrarErro(field, "Este campo é obrigatório");
      isValid = false;
    } else {
      limparErro(field);
    }
  });
  
  // Verificar se pelo menos uma tecnologia foi selecionada
  const techCheckboxes = document.querySelectorAll('input[name="technologies"]:checked');
  if (techCheckboxes.length === 0) {
    document.getElementById("tech-error").classList.remove("hidden");
    isValid = false;
  } else {
    document.getElementById("tech-error").classList.add("hidden");
  }
  
  // Verificar se os termos foram aceitos
  const termsCheckbox = document.getElementById("terms-agreement");
  if (!termsCheckbox.checked) {
    mostrarErro(termsCheckbox, "Você precisa aceitar os termos");
    isValid = false;
  } else {
    limparErro(termsCheckbox);
  }
  
  // Validar URLs
  const urlFields = ["download-link", "image-link"];
  urlFields.forEach(fieldId => {
    const field = document.getElementById(fieldId);
    if (field.value.trim() && !isValidURL(field.value)) {
      mostrarErro(field, "URL inválida");
      isValid = false;
    }
  });
  
  
  return isValid;
}

// Função auxiliar para validar URLs
function isValidURL(url) {
  try {
    new URL(url);
    return true;
  } catch (e) {
    return false;
  }
}

// Funções de exibição de erro
function mostrarErro(element, message) {
  // Adicionar classe de erro ao campo
  element.classList.add("error");
  
  // Verificar se já existe uma mensagem de erro
  let errorMsg = element.parentElement.querySelector(".error-message");
  if (!errorMsg) {
    errorMsg = document.createElement("div");
    errorMsg.className = "error-message";
    element.parentElement.appendChild(errorMsg);
  }
  
  errorMsg.textContent = message;
  errorMsg.classList.remove("hidden");
}

function limparErro(element) {
  element.classList.remove("error");
  const errorMsg = element.parentElement.querySelector(".error-message");
  if (errorMsg) {
    errorMsg.classList.add("hidden");
  }
}

// Função para exibir status de submissão
function mostrarStatus(sucesso, mensagem) {
  const statusElement = document.getElementById("submission-status");
  const statusIconSuccess = statusElement.querySelector(".status-icon.success");
  const statusIconError = statusElement.querySelector(".status-icon.error");
  const statusMessage = statusElement.querySelector(".status-message");
  
  // Ocultar ícones
  statusIconSuccess.classList.add("hidden");
  statusIconError.classList.add("hidden");
  
  // Exibir ícone adequado
  if (sucesso) {
    statusElement.classList.remove("error");
    statusElement.classList.add("success");
    statusIconSuccess.classList.remove("hidden");
  } else {
    statusElement.classList.remove("success");
    statusElement.classList.add("error");
    statusIconError.classList.remove("hidden");
  }
  
  // Definir mensagem
  statusMessage.textContent = mensagem;
  
  // Exibir status
  statusElement.classList.remove("hidden");
  
  // Ocultar após 5 segundos em caso de sucesso
  if (sucesso) {
    setTimeout(() => {
      statusElement.classList.add("hidden");
    }, 5000);
  }
}

// Função para ativar estado de loading no botão
function toggleLoadingButton(isLoading) {
  const submitBtn = document.getElementById("submit-button");
  const btnText = submitBtn.querySelector(".btn-text");
  const btnIcon = submitBtn.querySelector(".btn-icon i");
  
  if (isLoading) {
    submitBtn.classList.add("loading");
    btnText.textContent = "Enviando...";
    btnIcon.classList.remove("fa-paper-plane");
    btnIcon.classList.add("fa-spinner");
  } else {
    submitBtn.classList.remove("loading");
    btnText.textContent = "Enviar Bot";
    btnIcon.classList.remove("fa-spinner");
    btnIcon.classList.add("fa-paper-plane");
  }
}

// Verificar se o link da imagem é realmente uma imagem (pré-visualização)
function verificarImagemValida(imageUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(true);
    img.onerror = () => resolve(false);
    img.src = imageUrl;
  });
}

// Função para atualizar a prévia em tempo real
async function atualizarPrevia() {
  const botName = document.getElementById("bot-name").value || "Nome do Bot";
  const botDescription = document.getElementById("bot-description").value || "Descrição do seu bot aparecerá aqui...";
  const discordUsername = document.getElementById("discord-username").value || "você";
  const imageLink = document.getElementById("image-link").value;
  
  // Atualizar elementos da prévia
  document.getElementById("preview-name").textContent = botName;
  document.getElementById("preview-description").textContent = botDescription;
  document.getElementById("preview-discord").textContent = discordUsername;
  
  // Atualizar imagem se houver um link válido
  if (imageLink && isValidURL(imageLink)) {
    const previewImage = document.querySelector(".product-image");
    const isValidImage = await verificarImagemValida(imageLink);
    
    if (isValidImage) {
      previewImage.src = imageLink;
      limparErro(document.getElementById("image-link"));
    } else {
      previewImage.src = "/api/placeholder/400/200";
      // Não mostrar erro aqui, apenas no envio do formulário
    }
  }
  
  // Atualizar tecnologias
  const techContainer = document.getElementById("preview-technologies");
  const techSpan = techContainer.querySelector("span:first-child");
  
  const techCheckboxes = document.querySelectorAll('input[name="technologies"]:checked');
  const technologies = Array.from(techCheckboxes).map(checkbox => checkbox.value);
  
  techSpan.innerHTML = technologies.length > 0 
    ? `<i class="fas fa-code"></i> ${technologies.join(", ")}` 
    : '<i class="fas fa-code"></i> Tecnologias';
}

// Inicializar o contador de caracteres para a descrição
function inicializarContadorCaracteres() {
  const descricaoField = document.getElementById("bot-description");
  const counter = document.querySelector(".character-counter");
  
  descricaoField.addEventListener("input", () => {
    const count = descricaoField.value.length;
    counter.textContent = `${count}/300`;
    
    // Limitar a 300 caracteres
    if (count > 300) {
      descricaoField.value = descricaoField.value.substring(0, 300);
      counter.textContent = "300/300";
    }
    
    // Atualizar a prévia quando o usuário digita
    atualizarPrevia();
  });
}

// Registrar eventos após o carregamento do DOM
document.addEventListener("DOMContentLoaded", function() {
  const form = document.getElementById("bot-submission-form");
  
  // Inicializar o contador de caracteres
  inicializarContadorCaracteres();
  
  // Atualizar prévia ao alterar qualquer campo
  const formInputs = form.querySelectorAll("input, select, textarea");
  formInputs.forEach(input => {
    input.addEventListener("input", atualizarPrevia);
  });
  
  // Validação especial para o campo de imagem
  const imageInput = document.getElementById("image-link");
  imageInput.addEventListener("blur", async function() {
    const imageUrl = this.value.trim();
    
    if (imageUrl && isValidURL(imageUrl)) {
      const isImageValid = await verificarImagemValida(imageUrl);
      if (!isImageValid) {
        mostrarErro(this, "O link não parece ser uma imagem válida");
      }
    }
  });
  
  // Lidar com o envio do formulário
  form.addEventListener("submit", async function(event) {
    event.preventDefault();
    
    // Validar o formulário
    if (!validarFormulario()) {
      mostrarStatus(false, "Por favor, corrija os erros no formulário antes de enviar.");
      return;
    }
    
    // Ativar estado de loading
    toggleLoadingButton(true);
    
    // Coletar dados do formulário
    const dadosFormulario = coletarDadosFormulario();
    
    try {
      // Enviar dados para o Discord
      const discordEnviado = await enviarParaDiscord(dadosFormulario);
      
      if (discordEnviado) {
        // Mostrar mensagem de sucesso
        mostrarStatus(true, "Bot enviado com sucesso! Nossa equipe irá revisar e adicionar à biblioteca em breve.");
        
        // Limpar formulário
        form.reset();
        
        // Resetar prévia
        setTimeout(() => {
          atualizarPrevia();
        }, 500);
      } else {
        mostrarStatus(false, "Erro ao enviar notificação para nossa equipe. Tente novamente mais tarde.");
      }
    } catch (error) {
      console.error("Erro ao processar envio:", error);
      mostrarStatus(false, "Ocorreu um erro ao processar sua solicitação. Tente novamente mais tarde.");
    } finally {
      // Desativar estado de loading
      toggleLoadingButton(false);
    }
  });
});