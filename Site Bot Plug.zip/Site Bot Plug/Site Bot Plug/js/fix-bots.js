// Script para armazenar os bots no localStorage
// Este script deve ser incluído em todas as páginas principais (biblioteca.html, admin.html)

// Constantes
const STORAGE_KEYS = {
  ADMIN_BOTS: 'admin_bots',
  LIBRARY_BOTS: 'biblioteca_bots',
  SHARED_BOTS: 'shared_biblioteca_bots',
  USER_BOTS: 'botplug_saved_bots'
};

// Bots padrão para exibição na biblioteca
const DEFAULT_BOTS = [
  {
    id: 'bot1',
    name: 'Bate Ponto',
    category: 'bateponto',
    type: 'free',
    image: '/ponto.jpg',
    description: 'Bot completo para controle de presença com ranking',
    downloadLink: 'https://encurtalink.online/Bateponto',
    price: '',
    status: 'active',
    downloads: 1235,
    date: '10/05/2025',
    tags: 'discord, javascript, nodejs',
    contributor: '',
    rating: 5
  },
  {
    id: 'bot2',
    name: 'EncomendaBot',
    category: 'encomendas',
    type: 'free',
    image: '/Encomenda.png',
    description: 'Gerencie pedidos no Discord de forma organizada',
    downloadLink: 'https://fir3.net/encomendazip',
    price: '',
    status: 'featured',
    downloads: 3842,
    date: '15/04/2025',
    tags: 'discord, javascript, nodejs, mongodb',
    contributor: '',
    rating: 5
  },
  {
    id: 'bot3',
    name: 'Ticket Pro',
    category: 'premium',
    type: 'premium',
    image: '/ticket.png',
    description: 'Dashboard completo com estatísticas detalhadas',
    downloadLink: 'https://botplug.com/premium/ticket-pro',
    price: '10.90',
    status: 'active',
    downloads: 4382,
    date: '01/04/2025',
    tags: ' discord, nodejs',
    contributor: '',
    rating: 5
  },
  {
    id: 'bot4',
    name: 'Anti Raid/Spam',
    category: 'comunidade',
    type: 'community',
    image: '/Anti-raid-1.png',
    description: 'Bot de segurança avançado para Discord',
    downloadLink: 'https://fir3.net/antidistribuido',
    price: '',
    status: 'active',
    downloads: 201,
    date: '29/04/2025',
    tags: 'discord, nodejs,javascript,json',
    contributor: 'unknown',
    rating: 5
  },
  {
    id: 'bot5',
    name: 'ParceriaBot',
    category: 'comunidade',
    type: 'community',
    image: '/Parceria.png',
    description: 'Bot Parceria para Discord',
    downloadLink: 'https://fir3.net/parceriabot',
    price: '',
    status: 'active', 
    downloads: 55,
    date: '12/05/2025',
    tags: 'discord, nodejs,javascript,json',
    contributor: 'unknown',
    rating: 5
  }
];

// Função para garantir que existam bots no localStorage apenas uma vez na inicialização
function ensureBotsExist() {
  console.log('📦 Verificando se existem bots no localStorage...');
  
  // Verificar se já existem bots no localStorage
  const adminBots = localStorage.getItem(STORAGE_KEYS.ADMIN_BOTS);
  const libraryBots = localStorage.getItem(STORAGE_KEYS.LIBRARY_BOTS);
  
  // Só adicionar os bots padrão se não houver nenhum bot no localStorage
  if (!adminBots && !libraryBots) {
    console.log('📦 Carregando bots padrão no localStorage...');
    const botsJson = JSON.stringify(DEFAULT_BOTS);
    
    localStorage.setItem(STORAGE_KEYS.ADMIN_BOTS, botsJson);
    localStorage.setItem(STORAGE_KEYS.LIBRARY_BOTS, botsJson);
    localStorage.setItem(STORAGE_KEYS.SHARED_BOTS, botsJson);
    localStorage.setItem(STORAGE_KEYS.USER_BOTS, botsJson);
    
    console.log('✅ Bots padrão salvos no localStorage');
  } else {
    console.log('ℹ️ Bots já existem no localStorage, nenhuma ação necessária');
  }
}

// Garantir que existam bots no localStorage apenas uma vez na inicialização
ensureBotsExist();

// Não adicionar nenhum evento ou sincronização automática 