/**
 * modal-webhook.js
 * 
 * Este script lida com a funcionalidade de enviar respostas dos modais para um webhook do Discord.
 * Ele detecta quando um modal é aberto e configura os listeners de evento para o envio da resposta.
 */

document.addEventListener('DOMContentLoaded', function() {
  console.log('Modal Webhook script carregado!');
  
  // URL da API de webhook
  const WEBHOOK_API_URL = '/api/discord-webhook';
  
  // Função para mostrar mensagem de erro
  function showError(message) {
    const errorBox = document.createElement('div');
    errorBox.classList.add('error-message');
    errorBox.innerHTML = `
      <div class="error-box">
        <div class="error-icon">⚠️</div>
        <div class="error-content">
          <div class="error-title">Erro</div>
          <div class="error-text">${message}</div>
        </div>
        <button class="error-close">&times;</button>
      </div>
    `;
    
    // Estilos para a mensagem de erro
    errorBox.style.position = 'fixed';
    errorBox.style.top = '20px';
    errorBox.style.right = '20px';
    errorBox.style.zIndex = '9999';
    errorBox.style.backgroundColor = '#f44336';
    errorBox.style.color = 'white';
    errorBox.style.padding = '15px';
    errorBox.style.borderRadius = '5px';
    errorBox.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
    
    document.body.appendChild(errorBox);
    
    // Adicionar evento para fechar a mensagem
    const closeBtn = errorBox.querySelector('.error-close');
    closeBtn.addEventListener('click', function() {
      document.body.removeChild(errorBox);
    });
    
    // Remover automaticamente após 5 segundos
    setTimeout(() => {
      if (document.body.contains(errorBox)) {
        document.body.removeChild(errorBox);
      }
    }, 5000);
  }
  
  // Função para mostrar mensagem de sucesso
  function showSuccess(message) {
    const successBox = document.createElement('div');
    successBox.classList.add('success-message');
    successBox.innerHTML = `
      <div class="success-box">
        <div class="success-icon">✅</div>
        <div class="success-content">
          <div class="success-title">Sucesso</div>
          <div class="success-text">${message}</div>
        </div>
        <button class="success-close">&times;</button>
      </div>
    `;
    
    // Estilos para a mensagem de sucesso
    successBox.style.position = 'fixed';
    successBox.style.top = '20px';
    successBox.style.right = '20px';
    successBox.style.zIndex = '9999';
    successBox.style.backgroundColor = '#4CAF50';
    successBox.style.color = 'white';
    successBox.style.padding = '15px';
    successBox.style.borderRadius = '5px';
    successBox.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
    
    document.body.appendChild(successBox);
    
    // Adicionar evento para fechar a mensagem
    const closeBtn = successBox.querySelector('.success-close');
    closeBtn.addEventListener('click', function() {
      document.body.removeChild(successBox);
    });
    
    // Remover automaticamente após 5 segundos
    setTimeout(() => {
      if (document.body.contains(successBox)) {
        document.body.removeChild(successBox);
      }
    }, 5000);
  }
  
  // Função para enviar dados para o webhook
  async function sendToWebhook(data) {
    try {
      console.log("Enviando para o webhook:", data);
      const response = await fetch(WEBHOOK_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      
      const result = await response.json();
      
      console.log("Resposta do webhook:", result);
      
      if (response.ok) {
        console.log('Mensagem enviada com sucesso para o webhook:', result);
        return true;
      } else {
        console.error('Erro ao enviar para o webhook:', result);
        return false;
      }
    } catch (error) {
      console.error('Erro na requisição do webhook:', error);
      return false;
    }
  }
  
  // Configuração específica para o modal de upload de bot
  const uploadModal = document.getElementById('upload-modal');
  if (uploadModal) {
    console.log("Modal de upload de bot encontrado, configurando...");
    
    const submitBtn = document.getElementById('submit-bot');
    if (submitBtn) {
      // Preservar o comportamento original do botão de envio do modal-fix.js
      const originalClickHandler = submitBtn.onclick;
      
      submitBtn.addEventListener('click', async function(e) {
        // Não prevenir o evento padrão para permitir que o handler original seja executado
        console.log("Interceptando evento de clique para envio de webhook");
        
        // Obter dados do formulário - aba de repositório
        const botName = document.getElementById('bot-name-link').value;
        const repoUrl = document.getElementById('repo-url').value;
        
        if (!botName || !repoUrl) {
          console.log("Dados incompletos, não enviando webhook");
          return;
        }
        
        const message = `Bot enviado via repositório: ${repoUrl}`;
        
        // Obter informações do usuário
        let username = "Usuário Anônimo";
        try {
          const userData = localStorage.getItem('botplug_user');
          if (userData) {
            const user = JSON.parse(userData);
            username = user.username || "Usuário";
          }
        } catch (e) {
          console.error("Erro ao obter dados do usuário:", e);
        }
        
        // Enviar dados para o webhook
        const webhookData = {
          username: username,
          message: message,
          botName: botName,
          type: 'bot'
        };
        
        console.log("Dados para webhook:", webhookData);
        
        // Enviar após um pequeno delay para não interferir com a execução normal
        setTimeout(async () => {
          try {
            const success = await sendToWebhook(webhookData);
            if (success) {
              console.log("Webhook enviado com sucesso");
            } else {
              console.error("Falha ao enviar webhook");
            }
          } catch (error) {
            console.error("Erro ao enviar webhook:", error);
          }
        }, 500);
      });
    } else {
      console.error("Botão de submit não encontrado no modal de upload");
    }
  }
  
  // Observa o DOM para detectar quando um modal é aberto
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      if (mutation.type === 'attributes' && 
          mutation.attributeName === 'class' && 
          mutation.target.classList && 
          mutation.target.classList.contains('active')) {
        
        // Identificou que um modal foi aberto
        const modal = mutation.target;
        console.log('Modal detectado:', modal.id);
        
        // Pular o modal de upload de bot, pois já está configurado acima
        if (modal.id === 'upload-modal') {
          console.log('Modal de upload já configurado separadamente');
          return;
        }
        
        // Encontra o botão de enviar/submeter no modal
        const submitBtn = modal.querySelector('.submit-btn, button[type="submit"], .submit-report-btn');
        
        if (submitBtn) {
          console.log('Botão de enviar encontrado:', submitBtn);
          
          // Remove listeners anteriores para evitar duplicação
          const newSubmitBtn = submitBtn.cloneNode(true);
          submitBtn.parentNode.replaceChild(newSubmitBtn, submitBtn);
          
          // Adiciona novo listener
          newSubmitBtn.addEventListener('click', async function(e) {
            e.preventDefault();
            console.log('Botão de enviar clicado');
            
            // Processar formulário
            const form = modal.querySelector('form');
            if (!form) {
              console.error('Formulário não encontrado no modal');
              showError('Formulário não encontrado. Por favor, tente novamente.');
              return;
            }
            
            // Obter dados do formulário
            const formData = new FormData(form);
            const formDataObj = {};
            formData.forEach((value, key) => { formDataObj[key] = value; });
            
            // Obter informações do usuário
            let username = "Usuário Anônimo";
            try {
              const userData = localStorage.getItem('botplug_user');
              if (userData) {
                const user = JSON.parse(userData);
                username = user.username || "Usuário";
              }
            } catch (e) {
              console.error("Erro ao obter dados do usuário:", e);
            }
            
            // Preparar dados para o webhook
            const webhookData = {
              username: username,
              message: formDataObj.message || formDataObj.reportReason || "Sem mensagem",
              type: modal.id.includes('report') ? 'error' : 'feedback'
            };
            
            // Adicionar dados específicos dependendo do modal
            if (formDataObj.botName) {
              webhookData.botName = formDataObj.botName;
            } else if (formDataObj.reportBotName) {
              webhookData.botName = formDataObj.reportBotName;
            }
            
            if (formDataObj.email) {
              webhookData.email = formDataObj.email;
            }
            
            console.log('Enviando dados para o webhook:', webhookData);
            
            // Enviar para o webhook
            const success = await sendToWebhook(webhookData);
            
            if (success) {
              showSuccess('Sua mensagem foi enviada com sucesso!');
              
              // Reset do formulário
              form.reset();
              
              // Fechar o modal
              modal.classList.remove('active');
              if (modal.style) {
                modal.style.display = 'none';
              }
            } else {
              showError('Erro ao enviar sua mensagem. Por favor, tente novamente.');
            }
          });
        }
      }
    });
  });
  
  // Configura o observer para monitorar todos os modais da página
  const modalElements = document.querySelectorAll('.modal, .modal-overlay, .report-modal');
  
  if (modalElements.length > 0) {
    console.log(`Encontrados ${modalElements.length} modais para monitorar`);
    
    modalElements.forEach(modal => {
      observer.observe(modal, { attributes: true });
    });
  } else {
    console.warn('Nenhum modal encontrado na página atual');
  }
}); 